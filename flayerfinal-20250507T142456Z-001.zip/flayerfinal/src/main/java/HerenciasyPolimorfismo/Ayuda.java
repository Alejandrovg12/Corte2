/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package HerenciasyPolimorfismo;

/**
 *
 * @author alejo
 */
public class Ayuda {
    
    private String Devoluciones;
    private String GastosyFormasdeEnvio;
    private int cod_Ayuda;

    public Ayuda(String Devoluciones, String GastosyFormasdeEnvio, int cod_Ayuda) {
        this.Devoluciones = Devoluciones;
        this.GastosyFormasdeEnvio = GastosyFormasdeEnvio;
        this.cod_Ayuda = cod_Ayuda;
    }

    public String getDevoluciones() {
        return Devoluciones;
    }

    public String getGastosyFormasdeEnvio() {
        return GastosyFormasdeEnvio;
    }

    public int getCod_Ayuda() {
        return cod_Ayuda;
    }

    public void setDevoluciones(String Devoluciones) {
        this.Devoluciones = Devoluciones;
    }

    public void setGastosyFormasdeEnvio(String GastosyFormasdeEnvio) {
        this.GastosyFormasdeEnvio = GastosyFormasdeEnvio;
    }

    public void setCod_Ayuda(int cod_Ayuda) {
        this.cod_Ayuda = cod_Ayuda;
    }
    
    public String Ayuda() {
        return "Ayuda{" + "Devoluciones=" + Devoluciones + ", GastosyFormasdeEnvio=" + GastosyFormasdeEnvio + ", cod_Ayuda=" + cod_Ayuda + '}';
    }
    
}
