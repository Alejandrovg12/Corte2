/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package HerenciasyPolimorfismo;

/**
 *
 * @author alejo
 */
public class BarradeBusqueda {
    
    private String busqueda;
    private String Resultadodebusqueda;
    private String SugerenciasSegunlaBusqueda;
    private String LibrosMasActuales;
    private String cartelera;
    private String generodellibro;
    private String nombredellibro;
    private String nombredelautor;
    private String tipodellibro;
    private int cod_vis_libro;
    private String fecha;
    private int cod_busqueda;

    public BarradeBusqueda(String busqueda, String Resultadodebusqueda, String SugerenciasSegunlaBusqueda, String LibrosMasActuales, String cartelera, String generodellibro, String nombredellibro, String nombredelautor, String tipodellibro, int cod_vis_libro, String fecha, int cod_busqueda) {
        this.busqueda = busqueda;
        this.Resultadodebusqueda = Resultadodebusqueda;
        this.SugerenciasSegunlaBusqueda = SugerenciasSegunlaBusqueda;
        this.LibrosMasActuales = LibrosMasActuales;
        this.cartelera = cartelera;
        this.generodellibro = generodellibro;
        this.nombredellibro = nombredellibro;
        this.nombredelautor = nombredelautor;
        this.tipodellibro = tipodellibro;
        this.cod_vis_libro = cod_vis_libro;
        this.fecha = fecha;
        this.cod_busqueda = cod_busqueda;
    }

    public String getBusqueda() {
        return busqueda;
    }

    public String getResultadodebusqueda() {
        return Resultadodebusqueda;
    }

    public String getSugerenciasSegunlaBusqueda() {
        return SugerenciasSegunlaBusqueda;
    }

    public String getLibrosMasActuales() {
        return LibrosMasActuales;
    }

    public String getCartelera() {
        return cartelera;
    }

    public String getGenerodellibro() {
        return generodellibro;
    }

    public String getNombredellibro() {
        return nombredellibro;
    }

    public String getNombredelautor() {
        return nombredelautor;
    }

    public String getTipodellibro() {
        return tipodellibro;
    }

    public int getCod_vis_libro() {
        return cod_vis_libro;
    }

    public String getFecha() {
        return fecha;
    }

    public int getCod_busqueda() {
        return cod_busqueda;
    }

    public void setBusqueda(String busqueda) {
        this.busqueda = busqueda;
    }

    public void setResultadodebusqueda(String Resultadodebusqueda) {
        this.Resultadodebusqueda = Resultadodebusqueda;
    }

    public void setSugerenciasSegunlaBusqueda(String SugerenciasSegunlaBusqueda) {
        this.SugerenciasSegunlaBusqueda = SugerenciasSegunlaBusqueda;
    }

    public void setLibrosMasActuales(String LibrosMasActuales) {
        this.LibrosMasActuales = LibrosMasActuales;
    }

    public void setCartelera(String cartelera) {
        this.cartelera = cartelera;
    }

    public void setGenerodellibro(String generodellibro) {
        this.generodellibro = generodellibro;
    }

    public void setNombredellibro(String nombredellibro) {
        this.nombredellibro = nombredellibro;
    }

    public void setNombredelautor(String nombredelautor) {
        this.nombredelautor = nombredelautor;
    }

    public void setTipodellibro(String tipodellibro) {
        this.tipodellibro = tipodellibro;
    }

    public void setCod_vis_libro(int cod_vis_libro) {
        this.cod_vis_libro = cod_vis_libro;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public void setCod_busqueda(int cod_busqueda) {
        this.cod_busqueda = cod_busqueda;
    }

    public String busqueda() {
        return "BarradeBusqueda{" + "busqueda=" + busqueda + ", Resultadodebusqueda=" + Resultadodebusqueda + ", SugerenciasSegunlaBusqueda=" + SugerenciasSegunlaBusqueda + ", LibrosMasActuales=" + LibrosMasActuales + ", cartelera=" + cartelera + ", generodellibro=" + generodellibro + ", nombredellibro=" + nombredellibro + ", nombredelautor=" + nombredelautor + ", tipodellibro=" + tipodellibro + ", cod_vis_libro=" + cod_vis_libro + ", fecha=" + fecha + ", cod_busqueda=" + cod_busqueda + '}';
    }

    
    
}
