/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package HerenciasyPolimorfismo;

/**
 *
 * @author alejo
 */
public class AuTi {
    
    private String generodellibro;
    private String nombredellibro;
    private String nombredelautor;
    private String tipodellibro;
    private String fecha;
    private String cartelera;
    private int cod_autor;
    private int cod_tipodellibro;
    private int cod_AuTi;

    public AuTi(String generodellibro, String nombredellibro, String nombredelautor, String tipodellibro, String fecha, String cartelera, int cod_autor, int cod_tipodellibro, int cod_AuTi) {
        this.generodellibro = generodellibro;
        this.nombredellibro = nombredellibro;
        this.nombredelautor = nombredelautor;
        this.tipodellibro = tipodellibro;
        this.fecha = fecha;
        this.cartelera = cartelera;
        this.cod_autor = cod_autor;
        this.cod_tipodellibro = cod_tipodellibro;
        this.cod_AuTi = cod_AuTi;
    }

    public String getGenerodellibro() {
        return generodellibro;
    }

    public String getNombredellibro() {
        return nombredellibro;
    }

    public String getNombredelautor() {
        return nombredelautor;
    }

    public String getTipodellibro() {
        return tipodellibro;
    }

    public String getFecha() {
        return fecha;
    }

    public String getCartelera() {
        return cartelera;
    }

    public int getCod_autor() {
        return cod_autor;
    }

    public int getCod_tipodellibro() {
        return cod_tipodellibro;
    }

    public int getCod_AuTi() {
        return cod_AuTi;
    }

    public void setGenerodellibro(String generodellibro) {
        this.generodellibro = generodellibro;
    }

    public void setNombredellibro(String nombredellibro) {
        this.nombredellibro = nombredellibro;
    }

    public void setNombredelautor(String nombredelautor) {
        this.nombredelautor = nombredelautor;
    }

    public void setTipodellibro(String tipodellibro) {
        this.tipodellibro = tipodellibro;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public void setCartelera(String cartelera) {
        this.cartelera = cartelera;
    }

    public void setCod_autor(int cod_autor) {
        this.cod_autor = cod_autor;
    }

    public void setCod_tipodellibro(int cod_tipodellibro) {
        this.cod_tipodellibro = cod_tipodellibro;
    }

    public void setCod_AuTi(int cod_AuTi) {
        this.cod_AuTi = cod_AuTi;
    }
    

    public String AuTi() {
        return "AuTi{" + "generodellibro=" + generodellibro + ", nombredellibro=" + nombredellibro + ", nombredelautor=" + nombredelautor + ", tipodellibro=" + tipodellibro + ", fecha=" + fecha + ", cartelera=" + cartelera + ", cod_autor=" + cod_autor + ", cod_tipodellibro=" + cod_tipodellibro + ", cod_AuTi=" + cod_AuTi + '}';
    }
    
    
}
